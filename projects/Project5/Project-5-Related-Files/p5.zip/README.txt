调试方法
编译命令：clang++ -Wall -Werror -O0 -g --std=c++17 -fsanitize=leak -fsanitize=address -o ./rpn rpn.cpp
 - 加入调试选项-g，使打印gdb调试信息，且在使用valgrind或打开编译选项-fsanitize时，能打印内存泄漏的代码行号；
 - 把优化选项-O2暂时改为-O0，以免编译器自动优化代码，导致gdb调试时没有正常跳转
 - 打开编译选项-fsanitize=leak -fsanitize=address，方便调试。

rpn.cpp
 - 在107行、218行、178行出现了内存泄漏，查看代码发现均是 string* new_result = new string(s.str())，初步猜测是由于这里new的string没有释放导致。
 - 首先怀疑是析构函数没有执行成功。经调试，发现在析构函数调用removeAll()时，在调用isEmpty()时返回了0，代表list中已经没有元素了。
 - 进一步查看代码逻辑和调试，发现pop()方法调用的removeFront()是会将list中的node释放的。因此最后在析构函数调用removeAll()时，正常情况下list中已经没有node需要释放了。
 - 经过调试后，查出问题是由于在pop()方法内，调用的removeFront()中，只remove和释放了list中的first node，但没有把first node中存放的itr->op，也就是insert时new的string释放掉。
 - 因此将pop()的返回值改为node中存放的T *op，由用户在调用时手动释放。
 - 需要注意在调用top()后，必须保证在完成对返回的T *op的访问后，再对其进行释放。
同时修复了一些问题：
 - 删去在~Stack()析构函数中显式调用的~Dlist()。
 - 把Stack类的empty()方法改为了isEmpty()。用empty可能会被认为是动词清空。
 - 删去了多个不必要的string *临时变量的申请。
 - 修复了输入第一个字符为"（"时会导致程序异常崩溃的问题。

cache.cpp
 - 这里出现的内存泄漏问题和上面的类似，只要在调用removeBack()并完成访问返回的T *op后，对op进行释放即可。
 - 同时也删去了~LRUCache()中显式调用的~Dlist()。