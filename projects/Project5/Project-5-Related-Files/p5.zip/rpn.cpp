#include "dlist.h"
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

template <class T>
class Stack {
    private:
    Dlist<T> list;
    public:
    bool isEmpty(){
        return list.isEmpty();
    }

    T* pop() {
        if (!isEmpty()) 
            return list.removeFront();
        else 
            return nullptr;
    } 

    void push(T* val){
        //T *op = new T(val);
        list.insertFront(val);
    }

    T* top(){
        if (!isEmpty()) {
            T *itr = pop();
            push(itr);
            return itr;
        } else {
            return nullptr;
        }
    }
};

bool isParenthesis(const string& token){        
    return token == "(" || token == ")";      
} 

int cmpPrecedence(const string &token1, const string &token2){
    if(token2 == "*" || token2 == "/"){
        if(token1 == "+" || token1 == "-") return 1;
        else return 0;
    }
    if(token2 == "+" || token2 == "-"){
        if(token1 == "*" || token1 == "/") return -1;
        else return 0;
    }
    return 0;
}

bool isOperater(string &token){
    return token == "+" || token == "-" ||      
           token == "*" || token == "/";
}

int main(int argc, char const *argv[]){
    string output = "";
    Stack<string> stack;
    string token;
    string line;
    bool error_parent = 0;
    unsigned int i = 0;
    string *top_s;
    
    // Convert infix expression format into RPN   
    getline(cin,line);     
    
    while(i < line.size()){
        //clear the token
        token = "";
        
        //read a token
        while(i < line.size() && line[i] != ' '){
            token += line[i];
            i++;
        }
        i++;
        
        //if token is a operator
        if(isOperater(token)){
            // While there is an operator token, o2, at the top of the stack AND    
            // either o1 is left-associative AND its precedence is equal to that of o2,    
            // OR o1 has precedence less than that of o2,    
            if (!stack.isEmpty()) {
                top_s = stack.top();
                // cout << *top_s << endl;
                while (isOperater(*top_s) && cmpPrecedence(token,*top_s) >= 0) {
                    // pop top_s off the stack, onto the output;
                    output += *top_s;
                    output += ' ';
                    delete stack.pop();
                    if (!stack.isEmpty()) {
                        top_s = stack.top();
                        //cout << *top_s << endl;
                    } 
                    else break;
                }
            }        

            //push o1 onto the operator stack
            stack.push(new string(token));
        }
        else if(token == "("){
            stack.push(new string(token));
        } 
        else if(token == ")"){
            // Until the token at the top of the stack is a left parenthesis,     
            // pop operators off the stack onto the output queue.    
            if(!stack.isEmpty()) {
                top_s = stack.top();
                while (*top_s != "(") {
                    output += *top_s;
                    output += ' ';
                    delete stack.pop();
                    if (!stack.isEmpty()) {
                        top_s = stack.top();
                        //cout << *top_s << endl;
                    } 
                    else break;
                }
                
                // Pop the left parenthesis from the stack, but not onto the output
                if(!stack.isEmpty()) {
                    delete stack.pop();
                } 
                else {
                    // If the stack runs out without finding a left parenthesis,     
                    // then there are mismatched parentheses.                
                    cout << "ERROR: Parenthesis mismatch" << endl;
                    error_parent = 1;
                    break;
                }
            } 
            else {
                // If the stack runs out without finding a left parenthesis,     
                // then there are mismatched parentheses.                
                cout << "ERROR: Parenthesis mismatch" << endl;
                error_parent = 1;
                break;
            }                      
        }
        else{
            output += token;
            output += ' ';
        }        
    }

    // While there are still operator tokens in the stack
    while(!stack.isEmpty()){
        top_s = stack.top();
        // If the operator token on the top of the stack is a parenthesis,     
        // then there are mismatched parentheses.   
        if(isParenthesis(*top_s)){
                cout << "ERROR: Parenthesis mismatch" << endl;
                error_parent = 1;
                break;
        }
        // Pop the operator onto the output queue./    
        output += *top_s;   
        output += ' ';                 
        delete stack.pop();      
    }
    //cout the output
    if(error_parent) return 0;
    else cout << output << endl;
    i = 0;

    //compute value
    bool error_compute = 0;
    while(i < output.size()){
        //clear the token
        token = "";
        //read a token
        while(i < output.size() && output[i] != ' '){
            //cout << output[i] << endl;
            token += output[i];
            i++;
        }
        i++;
        //if it's a value, push it onto the stack
        if(!isOperater(token)){
            stack.push(new string(token));
        }
        else{
            int result = 0;
            // Token is an operator: pop top two entries
            if(stack.isEmpty()){
                cout << "ERROR: Not enough operands" << endl;
                error_compute = 1;
                break;
            }
            top_s = stack.top();
            int d2 = atoi((*top_s).c_str());
            delete stack.pop();
            if (!stack.isEmpty()) {
                top_s = stack.top();
                int d1 = atoi((*top_s).c_str());
                delete stack.pop();

                //Get the result
                if(token == "+") result = d1 + d2;
                else if(token == "-") result = d1 - d2;
                else if(token == "*") result = d1 * d2;
                else{
                    if(d2 == 0){
                        cout << "ERROR: Divide by zero" << endl;
                        error_compute = 1; 
                        break;
                    }
                    else result = d1 / d2; 
                }      
            }
            else{
                cout << "ERROR: Not enough operands" << endl;
                error_compute = 1;
                break;
            }
            // Push result onto stack       
            stack.push(new string(to_string(result)));
        }
    }

    //check if there are still operands in the stack besides the final result
    if(!stack.isEmpty()) {
        top_s = stack.pop();
        if(!stack.isEmpty()) {
            cout << "ERROR: Too many operands" << endl;
            error_compute = 1;
        }
        
        if (!error_compute) {
            cout << *top_s << endl;
        }
        delete top_s;
    }

    return 0;
}



