#include <iostream>
#include <string>
#include <cstring>
#include "recursive.h"
using namespace std;

list_t select(list_t lElements, list_t lIndices){
    
}
// REQUIRES: values in lIndices correspond to correct indices in lElements
//           indices in lIndices are in increasing order
// EFFECTS: returns all the elements of lElements (in the same order)
//          whose indices appear in lIndices


